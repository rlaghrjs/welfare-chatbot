import { useEffect, useState } from "react";

interface Policy {
  serv_id?: string | null;
  serv_nm?: string | null;
  serv_dgst?: string | null;
  serv_dtl_link?: string | null;

  service_id?: string | null;
  service_name?: string | null;
  summary?: string | null;
  raw_data?: any;
}

interface ChatMessage {
  id?: string;
  role: "user" | "assistant";
  content: string | null;
  message_type?: "text" | "welfare_cards" | "system";
  message_metadata?: {
    policies?: Policy[];
  } | null;
  created_at?: string;
}

interface ChatSession {
  session_id: string;
  title: string | null;
  status: string;
  created_at: string;
  ended_at: string | null;
}

interface SessionDetailResponse {
  session: ChatSession;
  messages: ChatMessage[];
}

export default function App() {
  const API_BASE_URL = "http://127.0.0.1:8000";

  const [sessions, setSessions] = useState<ChatSession[]>([]);
  const [sessionId, setSessionId] = useState<string>("");
  const [sessionTitle, setSessionTitle] = useState<string>("");

  const [message, setMessage] = useState<string>("");
  const [chatList, setChatList] = useState<ChatMessage[]>([]);
  const [loading, setLoading] = useState<boolean>(false);

  useEffect(() => {
    loadSessions();
  }, []);

  const formatDate = (value: string | null) => {
    if (!value) return "";

    const date = new Date(value);

    return date.toLocaleString("ko-KR", {
      month: "2-digit",
      day: "2-digit",
      hour: "2-digit",
      minute: "2-digit",
    });
  };

  const getPolicyId = (policy: Policy) => {
    return policy.serv_id || policy.service_id || "";
  };

  const getPolicyName = (policy: Policy) => {
    return policy.serv_nm || policy.service_name || "제도명 없음";
  };

  const getPolicySummary = (policy: Policy) => {
    return policy.serv_dgst || policy.summary || "요약 정보 없음";
  };

  const getPolicyLink = (policy: Policy) => {
    return policy.serv_dtl_link || policy.raw_data?.serv_dtl_link || "";
  };

  const loadSessions = async () => {
    try {
      const response = await fetch(`${API_BASE_URL}/api/chat/sessions`);

      if (!response.ok) {
        throw new Error("세션 목록 조회 실패");
      }

      const data: ChatSession[] = await response.json();
      setSessions(data);
    } catch (error) {
      console.error(error);
      alert("채팅 기록을 불러오지 못했습니다.");
    }
  };

  const createSession = async () => {
    try {
      const response = await fetch(`${API_BASE_URL}/api/chat/session`, {
        method: "POST",
      });

      if (!response.ok) {
        throw new Error("세션 생성 실패");
      }

      const data = await response.json();

      setSessionId(data.session_id);
      setSessionTitle(data.title || "새 채팅");

      setChatList([
        {
          role: "assistant",
          content: "채팅 세션이 시작되었습니다. 궁금한 복지제도를 입력해주세요.",
          message_type: "text",
        },
      ]);

      await loadSessions();
    } catch (error) {
      console.error(error);
      alert("세션 생성 중 오류가 발생했습니다.");
    }
  };

  const sendMessage = async () => {
    if (!sessionId) {
      alert("먼저 세션을 생성하세요.");
      return;
    }

    if (!message.trim()) return;

    const userMessage = message.trim();

    setChatList((prev) => [
      ...prev,
      {
        role: "user",
        content: userMessage,
        message_type: "text",
      },
    ]);

    setMessage("");
    setLoading(true);

    try {
      const response = await fetch(
        `${API_BASE_URL}/api/chat/session/${sessionId}/message`,
        {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify({
            message: userMessage,
          }),
        }
      );

      if (!response.ok) {
        throw new Error("메시지 전송 실패");
      }

      const data = await response.json();

      setChatList((prev) => [
        ...prev,
        {
          role: "assistant",
          content: data.answer,
          message_type: "text",
        },
      ]);

      if (data.policies && data.policies.length > 0) {
        setChatList((prev) => [
          ...prev,
          {
            role: "assistant",
            content: null,
            message_type: "welfare_cards",
            message_metadata: {
              policies: data.policies,
            },
          },
        ]);
      }

      if (!sessionTitle || sessionTitle === "새 채팅") {
        setSessionTitle(userMessage.slice(0, 30));
      }

      await loadSessions();
    } catch (error) {
      console.error(error);
      alert("메시지 처리 중 오류가 발생했습니다.");
    } finally {
      setLoading(false);
    }
  };

  const endSession = async () => {
    if (!sessionId) {
      alert("종료할 세션이 없습니다.");
      return;
    }

    try {
      const response = await fetch(
        `${API_BASE_URL}/api/chat/session/${sessionId}/end`,
        {
          method: "POST",
        }
      );

      if (!response.ok) {
        throw new Error("세션 종료 실패");
      }

      const data = await response.json();

      setChatList((prev) => [
        ...prev,
        {
          role: "assistant",
          content: `세션이 종료되었습니다. 상태: ${data.status}`,
          message_type: "system",
        },
      ]);

      setSessionId("");
      setSessionTitle("");

      await loadSessions();
    } catch (error) {
      console.error(error);
      alert("세션 종료 중 오류가 발생했습니다.");
    }
  };

  const loadSessionDetail = async (targetSessionId: string) => {
    try {
      const response = await fetch(
        `${API_BASE_URL}/api/chat/session/${targetSessionId}`
      );

      if (!response.ok) {
        throw new Error("세션 상세 조회 실패");
      }

      const data: SessionDetailResponse = await response.json();

      const restoredMessages: ChatMessage[] = data.messages.map((msg) => ({
        id: msg.id,
        role: msg.role,
        content: msg.content,
        message_type: msg.message_type || "text",
        message_metadata: msg.message_metadata ?? null,
        created_at: msg.created_at,
      }));

      setSessionId(data.session.session_id);
      setSessionTitle(data.session.title || "제목 없음");
      setChatList(restoredMessages);
    } catch (error) {
      console.error(error);
      alert("채팅 기록을 불러오지 못했습니다.");
    }
  };

  const renderPolicyCards = (policies: Policy[]) => {
    return (
      <div
        style={{
          marginTop: 4,
          display: "flex",
          flexDirection: "column",
          gap: 10,
        }}
      >
        {policies.map((policy, index) => (
          <div
            key={`${getPolicyId(policy)}-${index}`}
            style={{
              background: "#f8fafc",
              border: "1px solid #dbeafe",
              borderRadius: 12,
              padding: 12,
            }}
          >
            <div
              style={{
                fontWeight: 700,
                marginBottom: 8,
                color: "#1e3a8a",
              }}
            >
              {getPolicyName(policy)}
            </div>

            <div
              style={{
                fontSize: 14,
                lineHeight: 1.5,
                color: "#374151",
                marginBottom: 10,
              }}
            >
              {getPolicySummary(policy)}
            </div>

            {getPolicyLink(policy) && (
              <a
                href={getPolicyLink(policy)}
                target="_blank"
                rel="noreferrer"
                style={{
                  color: "#2563eb",
                  fontSize: 14,
                  textDecoration: "none",
                  fontWeight: 600,
                }}
              >
                상세보기 →
              </a>
            )}
          </div>
        ))}
      </div>
    );
  };

  const renderChatMessage = (chat: ChatMessage, index: number) => {
    const isUser = chat.role === "user";
    const isCardMessage = chat.message_type === "welfare_cards";

    if (isCardMessage) {
      const policies = chat.message_metadata?.policies ?? [];

      return (
        <div
          key={chat.id || index}
          style={{
            display: "flex",
            justifyContent: "flex-start",
            marginBottom: 16,
          }}
        >
          <div
            style={{
              maxWidth: "78%",
              padding: "12px 14px",
              borderRadius: 16,
              background: "#ffffff",
              border: "1px solid #e5e7eb",
              boxShadow: "0 1px 2px rgba(15, 23, 42, 0.08)",
            }}
          >
            {policies.length > 0 ? (
              renderPolicyCards(policies)
            ) : (
              <div style={{ color: "#64748b" }}>
                복지 검색 결과가 없습니다.
              </div>
            )}
          </div>
        </div>
      );
    }

    return (
      <div
        key={chat.id || index}
        style={{
          display: "flex",
          justifyContent: isUser ? "flex-end" : "flex-start",
          marginBottom: 16,
        }}
      >
        <div
          style={{
            maxWidth: isUser ? "65%" : "78%",
            padding: "12px 14px",
            borderRadius: 16,
            background: isUser ? "#2563eb" : "#ffffff",
            color: isUser ? "#ffffff" : "#111827",
            border: isUser ? "none" : "1px solid #e5e7eb",
            lineHeight: 1.5,
            boxShadow: !isUser ? "0 1px 2px rgba(15, 23, 42, 0.08)" : "none",
          }}
        >
          {chat.content}
        </div>
      </div>
    );
  };

  return (
    <div
      style={{
        height: "100vh",
        display: "grid",
        gridTemplateColumns: "280px 1fr",
        fontFamily: "Arial",
        background: "#f1f5f9",
      }}
    >
      <aside
        style={{
          borderRight: "1px solid #e5e7eb",
          background: "#ffffff",
          padding: 16,
          overflowY: "auto",
        }}
      >
        <button
          onClick={createSession}
          style={{
            width: "100%",
            padding: 12,
            borderRadius: 10,
            border: "none",
            background: "#2563eb",
            color: "#ffffff",
            fontWeight: 700,
            cursor: "pointer",
            marginBottom: 16,
          }}
        >
          새 채팅
        </button>

        <h3 style={{ margin: "8px 0 12px" }}>채팅 기록</h3>

        {sessions.length === 0 ? (
          <p style={{ color: "#64748b", fontSize: 14 }}>기록 없음</p>
        ) : (
          sessions.map((session) => (
            <button
              key={session.session_id}
              onClick={() => loadSessionDetail(session.session_id)}
              style={{
                width: "100%",
                textAlign: "left",
                padding: 12,
                borderRadius: 10,
                border:
                  session.session_id === sessionId
                    ? "1px solid #2563eb"
                    : "1px solid #e5e7eb",
                background:
                  session.session_id === sessionId ? "#eff6ff" : "#ffffff",
                marginBottom: 8,
                cursor: "pointer",
              }}
            >
              <div
                style={{
                  fontWeight: 700,
                  fontSize: 14,
                  color: "#111827",
                  overflow: "hidden",
                  textOverflow: "ellipsis",
                  whiteSpace: "nowrap",
                }}
              >
                {session.title || "제목 없음"}
              </div>

              <div
                style={{
                  marginTop: 6,
                  fontSize: 12,
                  color: "#64748b",
                  display: "flex",
                  justifyContent: "space-between",
                  gap: 8,
                }}
              >
                <span>{formatDate(session.created_at)}</span>
                <span>{session.status}</span>
              </div>
            </button>
          ))
        )}
      </aside>

      <main
        style={{
          display: "flex",
          flexDirection: "column",
          height: "100vh",
        }}
      >
        <header
          style={{
            height: 64,
            borderBottom: "1px solid #e5e7eb",
            background: "#ffffff",
            padding: "0 24px",
            display: "flex",
            alignItems: "center",
            justifyContent: "space-between",
          }}
        >
          <div>
            <h2 style={{ margin: 0 }}>{sessionTitle || "복지 챗봇"}</h2>

            <div
              style={{
                fontSize: 12,
                color: "#64748b",
                marginTop: 4,
              }}
            >
              {sessionId ? "세션 연결됨" : "새 채팅을 시작하세요"}
            </div>
          </div>

          <button
            onClick={endSession}
            disabled={!sessionId}
            style={{
              padding: "8px 12px",
              borderRadius: 8,
              border: "1px solid #e5e7eb",
              background: "#ffffff",
              cursor: sessionId ? "pointer" : "not-allowed",
            }}
          >
            세션 종료
          </button>
        </header>

        <section
          style={{
            flex: 1,
            overflowY: "auto",
            padding: 24,
          }}
        >
          {chatList.length === 0 && (
            <div
              style={{
                color: "#64748b",
                textAlign: "center",
                marginTop: 120,
              }}
            >
              왼쪽에서 새 채팅을 시작하거나 이전 기록을 선택하세요.
            </div>
          )}

          {chatList.map((chat, index) => renderChatMessage(chat, index))}

          {loading && (
            <p style={{ color: "#64748b" }}>복지 정보를 검색하는 중...</p>
          )}
        </section>

        <footer
          style={{
            borderTop: "1px solid #e5e7eb",
            background: "#ffffff",
            padding: 16,
            display: "flex",
            gap: 8,
          }}
        >
          <input
            value={message}
            onChange={(e) => setMessage(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === "Enter") sendMessage();
            }}
            placeholder="예: 청년 월세 지원 알려줘"
            disabled={!sessionId || loading}
            style={{
              flex: 1,
              padding: 12,
              border: "1px solid #ddd",
              borderRadius: 10,
            }}
          />

          <button
            onClick={sendMessage}
            disabled={!sessionId || loading}
            style={{
              padding: "0 18px",
              borderRadius: 10,
              border: "none",
              background: !sessionId || loading ? "#cbd5e1" : "#2563eb",
              color: "#ffffff",
              fontWeight: 700,
              cursor: !sessionId || loading ? "not-allowed" : "pointer",
            }}
          >
            전송
          </button>
        </footer>
      </main>
    </div>
  );
}